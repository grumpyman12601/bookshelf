// Window Object; size, open, close, move

window.addEventListener('resize', update);
var x = window.document.getElementById("resize");
update();

function update() [
x.innerHTML = "Browser inner window witch: " +
    window.innerWidth + ", height: " + winndow.innerHeight + ".";