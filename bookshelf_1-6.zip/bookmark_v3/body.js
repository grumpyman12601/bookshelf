document.addEventListener('DOMContentLoaded', function() {
    // Add event listener to the "Start" button
    document.getElementById('openPage').addEventListener('click', function(event) {
        // Prevent default behavior of the button
        event.preventDefault();
        
        // Open a new window with specified dimensions and styles
        var win = window.open('', 'transparentWindow', 'width=600,height=400,top=100,left=100,toolbar=0,location=0,status=0,menubar=0,scrollbars=0,resizable=0');
        
        // Write content into the new window
        win.document.write(`
            <html>
                <head>
                    <title>Window Title</title>
                    <link rel="stylesheet" href="offscreen.css">
                </head>
                <body>
                    <h1>Hello, World!</h1>
                </body>
            </html>
        `);
        
        // Make the window draggable if needed
        win.document.addEventListener('mousedown', function(event) {
            // Code for dragging the window if necessary
        });
    });

    // Add event listener to the "Move Window" button
    document.getElementById('moveButton').addEventListener('click', function(event) {
        // Your code to move the window goes here
    });

    // Add event listener to the "Close" button
    document.getElementById('closeButton').addEventListener('click', function(event) {
        // Your code to close the window goes here
    });
});