// Add event listener to the "Stop" button
document.getElementById('stopButton').addEventListener('click', function() {
  // Stop the operation of your extension
  // You may want to perform cleanup tasks or stop certain processes here
});