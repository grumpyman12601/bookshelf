document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('hideTab0').addEventListener('click', function() {
        // Logic to hide tab 0
        var tab0 = document.querySelector('#WebTab1 .ContentTabItem:nth-child(1)');
        if (tab0) {
            tab0.style.display = 'none';
        }
    });

    document.getElementById('hideSelectedTab').addEventListener('click', function() {
        // Logic to hide the selected tab
        var selectedTab = document.querySelector('#WebTab1 .ContentTabItem.selected');
        if (selectedTab) {
            selectedTab.style.display = 'none';
        }
    });
});