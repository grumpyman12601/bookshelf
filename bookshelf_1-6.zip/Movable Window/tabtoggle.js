<script type="text/javascript">
function hideTab(index)
{
 var webTab = $find('<%=WebTab1.ClientID%>');
 if(!webTab)
  return;
 //debugger;
 if(index == null)
 {
  index = webTab.get_selectedIndex();
  if(index < 0)
  {
   alert('There is no selected tab');
   return;
  }
 }
 var tab = webTab.getTabAt(index);
 if(!tab)
  alert('There is no tab at index:' + index);
 else
  tab.set_hidden(true);
}
</script>
  <ig:WebTab ID="WebTab1" runat="server" Height="240px" Width="470px">
   <Tabs>
    <ig:ContentTabItem runat="server" Text="Tab 1">
    </ig:ContentTabItem>
    <ig:ContentTabItem runat="server" Text="Tab 2">
    </ig:ContentTabItem>
    <ig:ContentTabItem runat="server" Text="Tab 3">
    </ig:ContentTabItem>
    <ig:ContentTabItem runat="server" Text="Tab 4">
    </ig:ContentTabItem>
   </Tabs>
  </ig:WebTab>
  <input type="button" value="hide 0" onclick="hideTab(0)" />
  <input type="button" value="hide selected" onclick="hideTab()" />

