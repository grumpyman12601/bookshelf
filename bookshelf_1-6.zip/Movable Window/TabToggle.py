def toggleTab(self, tab, visible):
		tabs = []
		idx = 0
		logger = system.util.getLogger('mylog')
		logger.info('toggling tab: %s %s' % (tab, visible))
		
		for c in self.children:
			metaTab = c.meta.tab
			name = c.meta.name
			logger.info('testing tab: %s %s' % (metaTab, name))
			
			if not metaTab:
				logger.warn('missing meta.tab on container: %s' % c.meta.name)
				return		
				
			if metaTab == tab:
				c.position.tabIndex = idx if visible else -1
			
			if c.position.tabIndex > -1:
				c.position.tabIndex = idx
				tabs.append(metaTab)
				idx = idx + 1
				logger.info('visible tab: %s' % metaTab)
			else:
				logger.info('hidden tab: %s' % metaTab)
						
		self.props.tabs = tabs
