const crypto = require("crypto");
crypto.randomBytes(16).toString("base64");